// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drive1               motor         11              
// Drive2               motor         12              
// Drive3               motor         14              
// Drive4               motor         18              
// Drive5               motor         19              
// Drive6               motor         20              
// Controller1          controller                    
// InertialSensor       inertial      13              
// Linkage              digital_out   E               
// Tilt                 digital_out   C               
// Claw                 digital_out   D               
// Puncher              motor_group   16, 15          
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
using namespace vex;
competition Competition;
double restPosition = 0;
bool toggle = false;



void Driver()
{
  startDriver();
}


void whenStarted()
{
  InertialSensor.startCalibration();
  waitUntil(!InertialSensor.isCalibrating());
  leftDriveMotors(Drive3, Drive2, Drive1);
  rightDriveMotors(Drive6, Drive5, Drive4);
  enableDrivetrain();
  //driveBrake();
  intake.setMaxTorque(100, percent);
  intake.setVelocity(90, percent);
  kicker.setMaxTorque(100, percent);
  kicker.setVelocity(100, percent);
  restPosition = kicker.position(deg); //assigns value to public variable
}


void intakeIn(){intake.spin(forward, 10 , voltageUnits::volt);}
void intakeOut(){intake.spin(forward, -10 , voltageUnits::volt);}
void intakeStop(){intake.spin(forward, 0 , voltageUnits::volt);}

void closeLWings(){LWing.set(false);}
void openLWings(){LWing.set(true);}

void openRWings(){RWing.set(true);}
void closeRWings(){RWing.set(false);}

void toggleKicker()
{
  if(toggle){
    kicker.stop();
    toggle = false;
  }else{
    kicker.spin(reverse, 150 ,pct);
    toggle = true;
  }
}

void toggleWings()
{if (LWing.value())
{LWing.set(false);}
else{LWing.set(true);}
if (RWing.value())
{RWing.set(false);}
else{RWing.set(true);}
}


void Auton()
{
 
}

void Farside()
{
  //b b r // blue offens
  move(95);
  turn(90);
 
  move(25);
  wait(500, msec);
  move(-20);                                                                                                                                        
  turn(0);
  move(-90);
  turn(-90);
  intakeIn();
  move(40);
  wait(.1, sec);
  move(-40);
  intakeStop();
  turn(0);
  move(80);
  turn(35);
  intakeOut();
  wait(.5, sec);
  turn(-25);
  intakeIn();  
  move(20);
  wait(.1,sec);
  intakeStop();
  turn(90);
  openLWings();
  move(45);
  move(60);
  turn(0);
  move(20);
}

void NearSide()
{
  //r b r
}

void Auton4()
{
  //b r b
}

void skillsAuton()
{
  
}


int main() 
{
  vexcodeInit();
  whenStarted();
  
  Brain.Screen.drawImageFromFile("winter50810.png", 0, 0); //Delete this if you want
  Competition.drivercontrol(Driver);
  Competition.autonomous(Farside);

  Controller1.ButtonL1.pressed(intakeOut);
  Controller1.ButtonR1.pressed(intakeIn);
  Controller1.ButtonL1.released(intakeStop);
  Controller1.ButtonR1.released(intakeStop);
  Controller1.ButtonUp.pressed(toggleWings);
  Controller1.ButtonA.pressed(toggleKicker);
  Controller1.ButtonL2.pressed(openLWings);
  Controller1.ButtonL2.released(closeLWings);
  Controller1.ButtonR2.pressed(openRWings);
  Controller1.ButtonR2.released(closeRWings);


}