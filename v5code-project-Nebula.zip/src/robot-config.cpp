#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor Drive1 = motor(PORT2, ratio6_1, true);
motor Drive2 = motor(PORT3, ratio6_1, false);
motor Drive3 = motor(PORT4, ratio6_1, false);
motor Drive4 = motor(PORT5, ratio6_1, true);
motor Drive5 = motor(PORT6, ratio6_1, false);
motor Drive6 = motor(PORT7, ratio6_1, true);
controller Controller1 = controller(primary);
inertial InertialSensor = inertial(PORT21);
digital_out LeftWing = digital_out(Brain.ThreeWirePort.G);
digital_out RightWing = digital_out(Brain.ThreeWirePort.E);
motor Drive7 = motor(PORT9, ratio6_1, false);
motor Drive8 = motor(PORT8, ratio6_1, true);
digital_out Claw = digital_out(Brain.ThreeWirePort.F);
digital_out Blocker = digital_out(Brain.ThreeWirePort.H);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}