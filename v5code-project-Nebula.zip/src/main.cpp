// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drive1               motor         1               
// Drive2               motor         2               
// Drive3               motor         3               
// Drive4               motor         4               
// Drive5               motor         10              
// Drive6               motor         9               
// Controller1          controller                    
// InertialSensor       inertial      21              
// LeftWing             digital_out   H               
// RightWing            digital_out   G               
// Claw                 digital_out   F               
// Dirve7               motor         8               
// Drive8               motor         7               
// ---- END VEXCODE CONFIGURED DEVICES ----


#include "vex.h"
using namespace vex;
competition Competition;

void Driver()
{
  startDriver();
  driveCoast();

}


void whenStarted()
{
  InertialSensor.calibrate();
  rightDriveMotors(Drive3, Drive2, Drive1, Drive4);
  leftDriveMotors(Drive8, Drive5, Drive6, Drive7);
  
  enableDrivetrain();
}

void openLeftWing()
{
  LeftWing.set(true);
}

void openRightWing()
{
  RightWing.set(true);
}

void closeLeftWing()
{
  LeftWing.set(false);
}

void closeRightWing()
{
  RightWing.set(false);
}

void openWings(){
  RightWing.set(true);
  LeftWing.set(true);
}
void closeWings(){
  RightWing.set(false);
  LeftWing.set(false);
}

void celebrate(){
repeat(3000){
 RightWing.set(true);
 LeftWing.set(true);
 Claw.set(true);
 wait(1, sec);
 Claw.set(false);
 RightWing.set(false);
 LeftWing.set(false);
 wait(1, sec); 
}
}

void blockeron(){
  Blocker.set(true);
}

void blockeroff(){
  Blocker.set(false);
}

void Clawon()
{Claw.set(true);}

void Clawoff()
{Claw.set(false);}

void Auton()
{
 openRightWing(); 
 wait(1, msec);
 move(15);
 closeRightWing();
 move(10);
 turn(-45);
 turn(13);
 move(-30);
 turn(25);
 
}


int main() 
{
  vexcodeInit();
  whenStarted();
  Competition.drivercontrol(Driver);
  Competition.autonomous(Auton);
  Controller1.ButtonR2.pressed(Clawon);
  Controller1.ButtonR2.released(Clawoff);
  Controller1.ButtonL1.pressed(openLeftWing);
  Controller1.ButtonL1.released(closeLeftWing);
  Controller1.ButtonR1.pressed(openRightWing);
  Controller1.ButtonR1.released(closeRightWing);
  Controller1.ButtonL2.pressed(openWings);
  Controller1.ButtonL2.released(closeWings);  
  Controller1.ButtonX.pressed(blockeron);
  Controller1.ButtonX.released(blockeroff);
}


