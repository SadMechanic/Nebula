using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor Drive1;
extern motor Drive2;
extern motor Drive3;
extern motor Drive4;
extern motor Drive5;
extern motor Drive6;
extern controller Controller1;
extern inertial InertialSensor;
extern digital_out LeftWing;
extern digital_out RightWing;
extern motor Drive7;
extern motor Drive8;
extern digital_out Claw;
extern digital_out Blocker;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );